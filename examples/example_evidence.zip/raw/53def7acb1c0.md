[ ![На головну](https://zakononline.ua/build/images/new-ldb-img/logo_v2.svg) ](https://zakononline.ua/) [ Тест 1 день ](https://zakononline.ua/court-decisions/show/42012854)
Вхід  [](https://zakononline.ua/court-decisions)
× 
### Моніторинг
Судові справи 473 Пошукові запити 473
Позначити як прочитані
##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1) ##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#2)
[ Додати справу ](https://zakononline.ua/court-decisions/show/42012854#the-lawsuit-popup) [ Перейти в розділ ](https://zakononline.ua/court-decisions/show/42012854)
Всі Судові рішення Прецеденти ЄСПЛ
Позначити як прочитані
##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1) ##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1) ##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1) ##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1) ##### [Оновлення в Господарських договорах Судові рішення 1 Дублювати Редагувати Видалити ](https://zakononline.ua/court-decisions/show/42012854#1)
Створити запит [ Перейти в розділ ](https://zakononline.ua/court-decisions/show/42012854)
×  [ ![](https://zakononline.ua/build/images/new-ldb-img/logo.svg) ](https://zakononline.ua/)
### Ви не авторизовані
Увійдіть в систему, або зареєструйтеся для отримання тестового доступу, щоб скористуватися усіма можливостями системи 
[ Тест 1 день ](https://zakononline.ua/court-decisions/show/42012854) Вхід
###### Розділи системи
#### [133 462 731 Судові рішення ](https://zakononline.ua/court-decisions?q=&target=) #### [28 925 Прецеденти ВС ](https://zakononline.ua/court-practice?q=&target=) #### [4 852 Прецеденти ЄСПЛ ](https://zakononline.ua/echr-practice?q=&target=) #### [544 726 Нормативні акти ](https://zakononline.ua/documents?q=&target=) #### [31 549 890 Судові засідання ](https://zakononline.ua/court-sessions?q=&target=) #### [54 448 600 Стан справ beta ](https://zakononline.ua/court-case-status)
[ Тарифи системи ](https://zakononline.ua/tariffs)
###### Унікальні можливості
[ ![](https://zakononline.ua/build/images/new-ldb-img/icon/main-menu-bell.svg) Моніторинг Відслідковуйте нові рішення та засідання по справі ](https://zakononline.ua/court-decisions/show/42012854) [ ![](https://zakononline.ua/build/images/new-ldb-img/icon/main-menu-calendar.svg) Календар засідань Слідкуйте за перебігом подій та синхронізуйте зі своїм календарем ](https://zakononline.ua/court-decisions/show/42012854) [ ![](https://zakononline.ua/build/images/new-ldb-img/icon/main-menu-star.svg) Обране Створюйте папки, зберігайте документи чи окремі цитати ](https://zakononline.ua/court-decisions/show/42012854) [ ![](https://zakononline.ua/build/images/new-ldb-img/icon/main-menu-folders.svg) Добірки прецедентів Правові позиції, на які варто звернути увагу ](https://zakononline.ua/arbitrage-groups)
###### Зв'яжіться з нами
##### [Про нас ](https://zakononline.ua/faq)
###### Комерційний відділ
[067-739-51-14](tel:0677395114) sales@zakononline.ua
###### Підтримка користувачів
[ ](https://t.me/+380675452626) [067-545-26-26](tel:0675452626) support@zakononline.ua
###### Загальні контакти
[044-300-20-36](tel:0443002036) info@zakononline.ua
###### Соціальні мережі
[ Facebook ](https://www.facebook.com/ZakonOnline/) [ Telegram ](https://t.me/zakononline2019) [ Instagram ](https://www.instagram.com/zakononline/)
Історія справи
Справа № 911/5439/14 
Приховати історію справи Показати історію справи Історія справи Засідання Рішення Стан
22.12.2014
  * [ Ухвала суду Господарський суд Київської області  ](https://zakononline.ua/court-decisions/show/42012854)


Немає даних
22.12.2014
  * [ Ухвала суду Господарський суд Київської області  ](https://zakononline.ua/court-decisions/show/42012854)


Немає даних
![](https://zakononline.ua/build/images/new-ldb-img/icon/mark-read.svg) Позначити все як переглянуте На моніторинг 
[ Судові рішення  ](https://zakononline.ua/court-decisions?q=&target=) [ Ухвала суду  ](https://zakononline.ua/court-decisions?page=1&limit=10&target=text&mode=sph04&judgement=5&sort=weight) Ухвала суду від 22.12.2014 по справі № 911/5439/14 Господарський суд Київської області 
Справа № 911/5439/14 
[ Історія справи ](https://zakononline.ua/cause/show/911___5439___14) На моніторинг 
Історія справи
Показати пошукові слова в тексті Сховати процесуальні документи
[ Перша 22.12.2014 Ухвала суду ](https://zakononline.ua/court-decisions/show/42012854)
#  Ухвала суду від 22.12.2014 по справі № 911/5439/14 Господарський суд Київської області 
Джерело:  [ **ЄДРСР 42012854** ](http://reyestr.court.gov.ua/Review/42012854) [ ![ЄДРСР 42012854](https://zakononline.ua/build/images/new-ldb-img/icon/arrow-right-top.svg) ](http://reyestr.court.gov.ua/Review/42012854)
Інстанція:  Перша інстанція 
Судочинство:  Господарське судочинство 
Суть:  Про стягнення заборгованості та штрафних санкцій 
Суддя:  Скутельник П.Ф. 
Результат рішення: 
**Резолютивна частина**
**Резолютивна частина**
![logo](https://zakononline.ua/build/images/new-ldb-img/logo.svg)
![](https://zakononline.ua/build/images/new-ldb-img/emblem.svg)
**ГОСПОДАРСЬКИЙ СУД**
**Київської області**
**01032, м. Київ - 32, вул. С.Петлюри, 16**
**тел. 239-72-81**
**У Х В А Л А**
"22" грудня 2014 р. Справа № 911/5439/14
Господарський суд Київської області в складі судді **Скутельника П.Ф.** , розглянувши матеріали
**за позовом** публічного акціонерного товариства "АКЦЕНТ-БАНК", ідентифікаційний код: 14360080, місцезнаходження: 49074, м. Дніпропетровськ, вул. Батумська, буд. 11,
**до** фізичної особи-підприємця Савченка Олексія Олександровича, ідентифікаційний номер: 2759610394, місце проживання: 09100, Київська обл., м. Біла Церква, вул. Шолом Алейхема, буд. 9, кв. 2,
**про** стягнення заборгованості та штрафних санкцій, -
**ВСТАНОВИВ:**
18.12.2014 року до господарського суду Київської області звернулось публічне акціонерне товариство "АКЦЕНТ-БАНК" з позовною заявою від 25.11.2014 року б/н (вх. № 5643/14 від 18.12.2014 року) до фізичної особи-підприємця Савченка Олексія Олександровича про стягнення заборгованості та штрафних санкцій.
Відповідно до ч. 3 ст. 57 Господарського процесуального кодексу України, до позовної заяви, підписаної представником позивача, додається довіреність чи інший документ, що підтверджує повноваження представника позивача.
Як вбачається з позовної заяви від 25.11.2014 року б/н, вказана позовна заява підписана представником ПАТ КБ «ПРИВАТБАНК» за довіреністю Сафір Ф.О.
На підтвердження наявності повноважень на підписання Сафір Ф.О. позовної заяви, Позивачем до позовної заяви додано копії довіреностей від 25.12.2012 року №986 та від 25.10.2012 року №3913-О.
Згідно копії довіреності від 25.12.2012 року №986, вказаною довіреністю публічним акціонерним товариством "АКЦЕНТ-БАНК" уповноважено публічне акціонерне товариство комерційний банк "ПРИВАТБАНК", зокрема, на представництво інтересів Позивача в загальних та спеціалізованих судах окремих судових юрисдикцій всіх інстанцій з правом підписувати, пред'являти та підтримувати позови. Вказана довіреність видана **без права передоручення** та є чинною до 31.12.2015 року.
Частиною 3 ст. 244 Цивільного кодексу України визначено, що довіреністю є письмовий документ, що видається однією особою іншій особі для представництва перед третіми особами. Довіреність на вчинення правочину представником може бути надана особою, яку представляють (довірителем), безпосередньо третій особі.
Тобто, довіреністю від 25.12.2012 року №986 публічне акціонерне товариство "АКЦЕНТ-БАНК" уповноважило на представництво своїх інтересів публічне акціонерне товариство комерційний банк "ПРИВАТБАНК" як юридичну особу **без можливості передоручення** наданих їй повноважень іншим особам.
Таким чином, позовна заява Позивача, яка подана його представником - публічним акціонерним товариством комерційний банк "ПРИВАТБАНК" може бути підписана виключно особою, що уповноважена діяти від імені публічного акціонерного товариства комерційний банк "ПРИВАТБАНК" відповідно до установчих документів.
Згідно загальнодоступних відомостей Єдиного державного реєстру юридичних осіб та фізичних осіб-підприємців, особами, які мають право представляти публічне акціонерне товариство комерційний банк "ПРИВАТБАНК" без довіреності є: ПІКУШ ЮРІЙ ПЕТРОВИЧ; НОВІКОВ ТИМУР ЮРІЙОВИЧ; ЯЦЕНКО ВОЛОДИМИР АНАТОЛІЙОВИЧ; ДУБІЛЕТ ОЛЕКСАНДР ВАЛЕРІЙОВИЧ; ГУР'ЄВА ТЕТЯНА МИХАЙЛІВНА; ШМАЛЬЧЕНКО ЛЮДМИЛА ОЛЕКСАНДРІВНА; КАНДАУРОВ ЮРІЙ ВАСИЛЬОВИЧ; ЧМОНА ЛЮБОВ ІВАНІВНА; ГОРОХОВСЬКИЙ ОЛЕГ ВОЛОДИМИРОВИЧ; ЗАВОРОТНИЙ ВОЛОДИМИР ГРИГОРОВИЧ; ЄРИКАЛОВА ІРИНА ОЛЕКСІЇВНА; ВІТЯЗЬ ОЛЕКСАНДР ПАВЛОВИЧ; КРИЖАНОВСЬКИЙ СТАНІСЛАВ ВІКЕНТІЙОВИЧ; НЕГИНСЬКИЙ РОМАН МАРКОВИЧ.
Разом з тим, відповідно до ч. 2 ст. 245 Цивільного кодексу України, довіреність, що видається у порядку передоручення, підлягає нотаріальному посвідченню, крім випадків, встановлених частиною четвертою цієї статті.
Довіреність від 25.10.2012 року №3913-О, якою публічне акціонерне товариство комерційний банк "ПРИВАТБАНК" уповноважило на представництво **своїх** інтересів Сафіра Ф.О. не посвідчена нотаріально.
За таких обставин, суд дійшов висновку про те, що позовна заява від 25.11.2014 року б/н підписана неуповноваженою особою.
Інших належних доказів наявності у Сафіра Ф.О. повноважень на підписання позовної заяви від 25.11.2014 року б/н Позивачем не надано.
Відповідно до п. 1 ч. 1 ст. 63 Господарського процесуального кодексу України, суддя повертає позовну заяву і додані до неї документи без розгляду, якщо: позовну заяву підписано особою, яка не має права її підписувати, або особою, посадове становище якої не вказано.
Згідно п. 3 ч. 1 ст. 57 Господарського процесуального кодексу України, до позовної заяви додаються документи, які підтверджують: сплату судового збору у встановлених порядку і розмірі.
Судом встановлено, що на підтвердження сплати судового збору за подання позовної заяви від 25.11.2014 року б/н Позивачем надано платіжне доручення від 25.11.2014 року №BOOO5B0NBN, згідно якого публічним акціонерним товариством комерційний банк "ПРИВАТБАНК" сплачено судовий збір у сумі 1 827,00 грн.; в графі «Призначення платежу» вказано: Судовий збір, за позовом ПАТ КБ "ПРИВАТБАНК" (до 2759610394, ФОП Савченко Олексій Олександрович) Господарський суд Київської обл., код ЄДРПОУ 37955989, п. 2.1).
Відповідно до ст. 2 Закону України «Про судовий збір», платники судового збору - громадяни України, іноземці, особи без громадянства, підприємства, установи, організації, інші юридичні особи (у тому числі іноземні) та фізичні особи - підприємці, **які звертаються до суду** чи стосовно яких ухвалене судове рішення, передбачене цим Законом.
Позивачем за позовною заявою від 25.11.2014 року б/н є публічного акціонерного товариства "АКЦЕНТ-БАНК", проте, до позовної заяви від 25.11.2014 року б/н додано платіжне доручення від 25.11.2014 року №BOOO5B0NBN, згідно якого платником є публічне акціонерне товариство комерційний банк "ПРИВАТБАНК". Разом з тим, у вказаному платіжному дорученні не зазначено, що судовий збір сплачується за подання позовної заяви публічного акціонерного товариства "АКЦЕНТ-БАНК".
Враховуючи вищевикладене, суд дійшов висновку про те, що платіжне доручення від 25.11.2014 року №BOOO5B0NBN не є належним доказом сплати судового збору за подання публічним акціонерним товариством "АКЦЕНТ-БАНК" позовної заяви від 25.11.2014 року б/н.
Згідно п. 4 ч. 1 ст. 63 Господарського процесуального кодексу України, суддя повертає позовну заяву і додані до неї документи без розгляду, якщо не подано доказів сплати судового збору у встановлених порядку та розмірі.
Таким чином, враховуючи те, що публічним акціонерним товариством "АКЦЕНТ-БАНК" при поданні позовної заяви від 25.11.2014 року б/н (вх. № 5643/14 від 18.12.2014 року) не дотримано вимог п. 3 ч. 1, ч. 3 ст. 57 Господарського процесуального кодексу України, суд, на підставі п.п. 1, 4 ч. 1 ст. 63 Господарського процесуального кодексу України, дійшов висновку про повернення позовної заяви від 25.11.2014 року б/н публічному акціонерному товариству "АКЦЕНТ-БАНК" без розгляду.
Керуючись ст. ст. 56, 57, 63, 86 Господарського процесуального кодексу України, суд -
**УХВАЛИВ:**
**1.** Позовну заяву публічного акціонерного товариства "АКЦЕНТ-БАНК" від 25.11.2014 року б/н (вх. № 5643/14 від 18.12.2014 року) повернути позивачу без розгляду.
**2.** Копію ухвали надіслати позивачу та відповідачу; позовну заяву від 25.11.2014 року б/н (вх. № 5643/14 від 18.12.2014 року) з доданими документами всього на 54 (п'ятдесят чотири) арк. направити публічному акціонерному товариству "АКЦЕНТ-БАНК".
_Повернення позовної заяви не перешкоджає повторному зверненню з нею до господарського суду в загальному порядку після усунення допущенного порушення._
**Суддя П.Ф. Скутельник**
Джерело:[ЄДРСР 42012854](http://reyestr.court.gov.ua/Review/42012854)
[](https://zakononline.ua/court-decisions/show/42012854)
Зачекайте, будь ласка. Генеруються посилання на нормативну базу...
[](https://zakononline.ua/court-decisions/show/42012854)
Посилання згенеровані. Перезавантажте сторінку
[![](https://zakononline.ua/build/images/new-ldb-img/footer-logo.png)](https://zakononline.ua/)
Комерційний відділ
[067-739-51-14](tel:0677395114) sales@zakononline.ua
Підтримка користувачів
[ ](https://t.me/+380675452626) [067-545-26-26](tel:0675452626) support@zakononline.ua
Загальні контакти
[044-300-20-36](tel:0443002036) info@zakononline.ua
Соціальні мережі
[ ![](https://zakononline.ua/build/images/new-ldb-img/icon/facebook-white.svg) Facebook ](https://www.facebook.com/ZakonOnline/) [ ![](https://zakononline.ua/build/images/new-ldb-img/icon/telegram-white.svg) Telegram ](https://t.me/zakononline2019) [ ![](https://zakononline.ua/build/images/new-ldb-img/icon/instagram-white.svg) Instagram ](https://www.instagram.com/zakononline/)
Нормативні акти
[Закони](https://zakononline.ua/zakony) [Кодекси](https://zakononline.ua/kodeksy) [Конституція](https://zakononline.ua/konstytutsiya) [Листи](https://zakononline.ua/lysty) [Накази](https://zakononline.ua/nakazy) [Положення](https://zakononline.ua/polozhennya) [Порядки](https://zakononline.ua/poryadky) [Постанови](https://zakononline.ua/postanovy) [Рішення](https://zakononline.ua/rishennya) [Розпорядження](https://zakononline.ua/rozporyadzhennya) [Роз’яснення](https://zakononline.ua/rozyasnennya) [Укази](https://zakononline.ua/ukazy)
Судова практика
[Адміністративний процес](https://zakononline.ua/administrativnij-proces-v-ukrayini) [Аліменти](https://zakononline.ua/alimenti) [Архітектура](https://zakononline.ua/arhitektura-usih-chasiv-svitu) [Банкрутство](https://zakononline.ua/bankrutstvo-fizychnykh-ta-yurydychnykh-osib) [Будівництво](https://zakononline.ua/budivnictvo) [Визнання батьківства](https://zakononline.ua/viznannya-batkivstva) [Визнання правочину недійсним](https://zakononline.ua/viznannya-pravochinu-nedijsnim) [Визначення місця проживання дитини](https://zakononline.ua/viznachennya-miscya-prozhivannya-ditini) [Витрати](https://zakononline.ua/vitrati-u-sudi-derzhavnij-zbir-ta-chastina-procesu) [Відчуження земельної ділянки](https://zakononline.ua/vidchuzhennya-zemelnoyi-dilyanki) [Власність](https://zakononline.ua/formi-vlasnosti) [Головна сторінка](https://zakononline.ua/court-decisions/show/42012854) [Господарський процес](https://zakononline.ua/gospodarskij-proces) [Довіреність](https://zakononline.ua/dovirenist) [Договір](https://zakononline.ua/gospodarskij-dogovir) [Дозволи на будівництво](https://zakononline.ua/dozvoli-vidacha-dozvoliv) [Докази-доказування](https://zakononline.ua/dokazi-dokazuvannya) [Забезпечення](https://zakononline.ua/zahodi-zabezpechennya-kriminalnogo-provadzhennya-sho-soboyu-yavlyayut-ta-yaki-isnuyut) [Законодавство](https://zakononline.ua/osnovni-galuzi-zakonodavstva-ukrayini) [Запобіжні заходи](https://zakononline.ua/specialna-konfiskaciya-majna-u-kku) [Заробітна плата](https://zakononline.ua/minimalna-zarobitnya-plata-osoblivosti-formuvannya-ta-pravila-viplati) [Затримання особи](https://zakononline.ua/zatrimannya-osobi) [Захист](https://zakononline.ua/civilnij-zahist) [ЗЕД](https://zakononline.ua/klasifikaciya-tovariv-zovnishnoekonomichnoyi-diyalnosti) [Землекористування](https://zakononline.ua/postijne-zemlekoristuvannya) [Злочини](https://zakononline.ua/sho-take-zlochin) [Зобов'язання](https://zakononline.ua/zobovyazannya-yak-pravovij-termin) [Інтелектуальна власність](https://zakononline.ua/ponyattya-ta-zahist-intelektualnoyi-vlasnosti) [Кримінальна відповідальність](https://zakononline.ua/use-pro-kriminalnu-vidpovidalnist) [Кримінальний процес](https://zakononline.ua/kriminalnij-proces-zagalni-polozhennya-ponyattya) [Ліцензування](https://zakononline.ua/licenzuvannya-ta-vidi-licenzij) [Майно](https://zakononline.ua/reyestraciya-majnovih-prav) [Матеріальна відповідальність](https://zakononline.ua/povna-ta-chastkova-materialna-vidpovidalnist) [Моніторинг](https://zakononline.ua/monitoring-ta-funkcional) [Набуття та визнання](https://zakononline.ua/nabuttya-viznannya-prav-ta-statusiv) [Обвинувачення](https://zakononline.ua/privatne-ta-publichne-obvinuvachennya) [Опіка та піклування](https://zakononline.ua/opika-ta-pikluvannya-nad-nepovnolitnoyu-ditinoyu) [Оренда землі](https://zakononline.ua/orenda-zemli-v-ukrayini) [Оскарження](https://zakononline.ua/rizni-vidi-oskarzhennya-zagalni-polozhennya) [Пенсія. Соціальні виплати](https://zakononline.ua/rozrahunok-pensiyi-v-ukrayini) [Повідомлення про підозру](https://zakononline.ua/povidomlennya-pro-pidozru-zagalni-polozhennya) [Позов](https://zakononline.ua/zabezpechennya-pozovu-ta-groshova-kompensaciya-pid-chas-kriminalnogo-provadzhennya) [Покарання](https://zakononline.ua/pokarannya-yak-vid-kriminalnoyi-vidpovidalnosti) [Поновлення на роботі](https://zakononline.ua/osoblivosti-ponovlennya-na-roboti-pislya-nezakonnogo-zvilnennya) [Права](https://zakononline.ua/majnovi-ta-nemajnovi-prava-gromadyanina-ukrayini) [Правочин](https://zakononline.ua/pravochin-yak-nevidyemna-skladova-zhittya-gromadyanina) [Представництво](https://zakononline.ua/predstavnictvo-v-civilnomu-procesi) [Презумпція невинуватості](https://zakononline.ua/prezumpciya-nevinuvatosti) [Прецеденти ВС](https://zakononline.ua/korotko-pro-pravovi-poziciyi-verhovnogo-sudu) [Провадження](https://zakononline.ua/vikonavche-kriminalne-provadzhennya) [Продаж земель](https://zakononline.ua/prodazh-zemel-silskogospodarskogo-priznachennya) [Процесуальні строки](https://zakononline.ua/procesualni-stroki-v-gospodarskomu-procesi) [Рішення](https://zakononline.ua/yedinij-reyestr-sudovih-rishen) [Самочинне будівництво](https://zakononline.ua/samochinne-budivnitstvo) [Санкції](https://zakononline.ua/sankciya-yak-zasib-derzhavnogo-administrativnogo-regulyuvannya-ta-pokarannya) [Сервітут](https://zakononline.ua/pravovi-osoblivosti-servitutu) [Склад суду](https://zakononline.ua/sudova-sistema-ukrayini-sklad-suddiv) [Слідчі розшукові дії](https://zakononline.ua/glasni-ta-neglasni-slidchi-diyi) [Соціальні права. Пільги](https://zakononline.ua/vidi-lgot-dlya-naselennya-ukrayini) [Спадкування](https://zakononline.ua/spadok-ta-prava-nasliduvannya-za-civilnim-kodeksom-ukrayini) [Спеціальна конфіскація](https://zakononline.ua/specialna-konfiskaciya-majna-u-kku) [Спори](https://zakononline.ua/vidi-pravovih-sporiv) [Стандартизація](https://zakononline.ua/standartizaciya-yak-sposib-kontrolyu) [Суд](https://zakononline.ua/sistema-sudoustroyu-v-ukrayini) [Судова практика](https://zakononline.ua/sudova-praktika) [Судові засідання](https://zakononline.ua/suchasni-osoblivosti-sudovih-zasidan) [Судочинство](https://zakononline.ua/administrativne-sudochinstvo-v-ukrayini) [Угода](https://zakononline.ua/ugoda-yak-forma-suspilnih-vidnosin) [Усиновлення](https://zakononline.ua/usinovlennya-ditini-v-ukrayini) [Усунення перешкод](https://zakononline.ua/usunennya-pereshkod-u-vikoristanni-majna) [Ухвала](https://zakononline.ua/uhvala-sudu) [Цивільна дієздатність](https://zakononline.ua/civilna-diyezdatnist) [Цивільний процес](https://zakononline.ua/civilnij-proces-forma-zahistu-prav-gromadyanina) [Цінні папери](https://zakononline.ua/cinni-paperi) [Шкода та збитки](https://zakononline.ua/shkoda-ta-zbitki)
Показати все 
![MasterCard](https://zakononline.ua/build/images/nonoptimised/payments/mastercard.png) ![Visa](https://zakononline.ua/build/images/nonoptimised/payments/visa.png)
[Публічна оферта ФОП Мирида В. А.](https://zakononline.ua/agreement3) [Публічна оферта ФОП Берназюк О.О.](https://zakononline.ua/agreement-fop) [Публічна оферта ТОВ ІПС](https://zakononline.ua/agreement) [Конфіденційність](https://zakononline.ua/confidentiality) [Статті](https://zakononline.ua/blog)
Ⓒ ZAKONONLINE, 2026 
× ![](https://zakononline.ua/build/images/new-ldb-img/payment-modal-logo.svg)
Ця функція стане доступною в повній версії продукту
Безкоштовний доступ на 1 день
Тестувати 
Повний доступ до системи
[Придбати](https://zakononline.ua/tariffs)
В мене вже є акаунт
Вхід 
Контакти технічної підтримки: [067-545-26-26](tel:0675452626)
support@zakononline.ua
![](https://zakononline.ua/build/images/new-ldb-img/payment-modal-logo.svg)
Ця функція стане доступною в повній версії продукту
Безкоштовний доступ на 1 день
Тестувати 
Повний доступ до системи
[Придбати](https://zakononline.ua/tariffs)
В мене вже є акаунт
Вхід 
Контакти технічної підтримки: [067-545-26-26](tel:0675452626)
support@zakononline.ua
×
![](https://zakononline.ua/build/images/new-ldb-img/icon/error.svg)
Спробуйте перезавантажити сторінку або перейдіть на головну.
* * *
[Перезавантажити](https://zakononline.ua/court-decisions/show/42012854) [Перейти на головну](https://zakononline.ua/)
Усі зміни збережені
Вкажіть код ЄДПРОУ або назву контрагенту
Додайте коментар
Активовано
Зберегти Відмінити
Вкажіть повний номер справи
Додайте коментар
Про що повідомляти?
Нові рішення
Нові засідання
Активовано
Зберегти Відмінити
**Об'єкт не знайдено**
скопійовано  [![Копіювати](https://zakononline.ua/build/images/nonoptimised/svg/copy-icon.svg)](https://zakononline.ua/court-decisions/show/42012854)
[![Зберегти](https://zakononline.ua/build/images/nonoptimised/svg/chosen-icon.svg)](https://zakononline.ua/court-decisions/show/42012854)
[![Шукати у розділу](https://zakononline.ua/build/images/nonoptimised/svg/search-blue.svg)](https://zakononline.ua/court-decisions/show/42012854)
## Зберегти в обраному
Інформація збережена
Назва в обраному
Коментар
Оберіть проект
[](https://zakononline.ua/court-decisions/show/42012854 "Створити новий проект")
Оберіть колір
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)
  * [](https://zakononline.ua/court-decisions/show/42012854)


[Відмінити](https://zakononline.ua/court-decisions/show/42012854)
## Надіслати на вказаний адрес
[](https://zakononline.ua/court-decisions/show/42012854)
Документ відправлено на електронну адресу 
### Шановний користувач!
[](https://zakononline.ua/court-decisions/show/42012854)
Ця функція незабаром стане доступною.
{CONTENT} 
Більше не показувати Нагадати пізніше
[](https://zakononline.ua/court-decisions/show/42012854)
